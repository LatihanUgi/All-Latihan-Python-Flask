WTF_CSRF_ENABLED = True
SECRET_KEY = 'komandro'
UPLOAD_FOLDER = 'app/static/photo_admin/'
ALLOWED_EXTENSIONS = (['png', 'jpg', 'jpeg'])
